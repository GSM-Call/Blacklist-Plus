<?php
$blacklist = FreePBX::create()->Blacklist;
echo $blacklist->showPage();
