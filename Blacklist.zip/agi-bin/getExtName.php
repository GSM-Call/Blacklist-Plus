#!/usr/bin/php -q
<?php
require_once "/var/lib/asterisk/agi-bin/phpagi.php";
$agi = new AGI();

// Prepare connection for our MySQL 
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "passw0rd");
define("DB_NAME", "asterisk");

$dbh = new mysqli(DB_SERVER, DB_USER, DB_PASS, DB_NAME);   
$sql = "SELECT * FROM `users` WHERE `extension` = '" . $argv[1]. "'";
//$sql = "SELECT * FROM users WHERE extension = '888'";
$data= $dbh->query($sql);
$row = $data->fetch_array();

$ext_nam1 = $row[2];
$agi->set_variable("ext_nam", trim($ext_nam1));
$agi->verbose('----------> Extension Num: ' . $argv[1]);
$agi->verbose('----------> Extension Name: ' . $ext_nam1);

?>