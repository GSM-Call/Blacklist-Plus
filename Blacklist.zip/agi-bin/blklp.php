#!/usr/bin/php -q
<?php
// Bootstrap FreePBX but don't include any modules (so you won't get anything
// from the functions.inc.php files of all the modules.)

/* $restrict_mods = true;
if (!@include_once(getenv('FREEPBX_CONF') ? getenv('FREEPBX_CONF') : '/etc/freepbx.conf')) {
        include_once('/etc/asterisk/freepbx.conf');
} */

// Connect to AGI:
require_once "/var/lib/asterisk/agi-bin/phpagi.php";
$agi = new AGI();
// Prepare out current timestamp
date_default_timezone_set("America/New_York");
$ymdNow = date("m/d/Y") . ' @ ' . date("h:i:sa");
// Prepare connection for our MySQL 
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "passw0rd");
define("DB_NAME", "gsmcall");
$dbh = new mysqli(DB_SERVER, DB_USER, DB_PASS, DB_NAME);

$agi->verbose("-----------------------------------------");
//$agi->noop("My CalleID: <<<<<<<=".$ani);
$blk_num = (int)$argv[1];
$blker = $argv[2];
$dial_num = (int)$argv[3];

if ($dial_num != 31){
	$lookupcid = $argv[4];
	$agi->verbose('This is the CallerID ' . $lookupcid);
	$agi->verbose("-----------------------------------------");

	$sql = "INSERT INTO blacklist (tn, ab, mu, ts, de) VALUES ('" . $blk_num ."', '" . $blker ."', 'Dial *" . $dial_num . "', '". $ymdNow . "', '" . $lookupcid . "')";
	$dbh->query($sql);
	$dbh->close;
} elseif ($dial_num == 31) {
	$emailTo = $argv[4];

	// get blocktime before Deteling the record
	
	$sql = "SELECT * FROM `blacklist` WHERE `tn` = '" . $blk_num . "'";
	$data= $dbh->query($sql);
	$row = $data->fetch_assoc();
	$result = $row['ts'];
	$result2 = $row['ab'];
    
	$agi->set_variable("blkts", trim($result));
	$agi->set_variable("blkab", trim($result2));
	
	$agi->verbose('Unblocker # --> ' . $blker);
	$agi->verbose('Was Blocker By --> ' . $result2);
	$agi->verbose('Number unblocked --> '. $blk_num);
	$agi->verbose('TO Email --> '. $emailTo);
	$agi->verbose('Time Number was Blocked on --> '. $result);
	$agi->verbose("---------------------------------------------------");
	
	// Delete the record from MySQL
	$sql = "DELETE FROM blacklist WHERE tn = '" . (int)$argv[1] . "' LIMIT 1";
	$dbh->query($sql);
	$dbh->close;		
}
?>