#!/usr/bin/php -q
<?php
// The below line is the call to this script from the Asterisk Dialplan
//exten => 1,n,AGI(/var/www/html/MyProject/mail_dialp.php,${blacknr},${CALLERID(number)},${DIAL_NUM},${EMAILTO})
require_once "/var/lib/asterisk/agi-bin/phpagi.php";
$agi = new AGI();

// Loading the PHPMailer helper
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require_once "vendor/autoload.php";

// Setting a variable for Current time stamp.
date_default_timezone_set("America/New_York");
$ymdNow = date("m/d/Y") . ' @ ' . date("h:i:sa");

// Setting variables for HTML presentation.
// 	Get the TO email

$blk_num = (int)$argv[1];
$blkerr = $argv[2];
$dialed_number = (int)$argv[3];
$modde = $dialed_number;
$toMail = $argv[4];
$clrid = $argv[5];
$pbx_1 = explode(".", gethostname());
$pbx = ucfirst(strtolower($pbx_1[0]));
$HTMLmsg = '';

$agi->verbose('----------> Blacklist # ' . $blk_num);
$agi->verbose('----------> Blocker ' . $blkerr);
$agi->verbose('----------> Dial ' . $dialed_number);
if (!empty($argv[4])) {
	$agi->verbose('----------> Mail To ' . $toMail);
}
$agi->verbose('----------> CallerID of Blacklist # ' . $clrid);
$agi->verbose('----------> Your PBX ' . $pbx);

if (empty($toMail)){
$agi->verbose('----------> No Email Box Saved, EXITSING script now without sending emails');	
	exit;
}

//PHPMailer Object
$mail = new PHPMailer(true); //Argument true in constructor enables exceptions
//From email address and name
$mail->From = "support@gsmcall.com";
$mail->FromName = "BlackList Module Notification";
//To address and name
$mail->addAddress($toMail);
//$mail->addAddress("recepient1@example.com", "Recipient_name"); //Recipient name is optional
//Address to which recipient will reply
$mail->addReplyTo("support@gsmcall.com", "Reply");
//Send HTML or Plain Text email
$mail->isHTML(true);

// switch between add and modify
if ($modde == 30){
	$msg = 'A number has been added to ' . $pbx . '\'s blacklist callers via feature code *30.';
	$mail->Subject = "A new callerID was just added to " . $pbx . "'s blacklist";
	$state = 'Blocked ';
	$f_color = "#FA0404";
	$state_time = $ymdNow ;
} elseif ($modde == 31) {
	$msg = 'A blacklisted number has just been removed from ' . $pbx . '\'s PBX via feature code *31';
	$mail->Subject = "A callerID has just been unblocked from " . $pbx . "'s blacklist";
	$state = 'Un-Blocked ';
	$f_color = "#83F905";
	$state_time = $argv[6];
	$orig_blkerr = $argv[7];
	$HTMLmsg = '
				<td style="font-size:9px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Originally Blocked By:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $orig_blkerr . '</h2>
                    </td>
                  </tr>
                </tbody>';
	
} elseif ($modde == 33) {
	$msg = 'A number has been added to ' . $pbx . '\'s blacklist callers via feature code *33.';
	$mail->Subject = "A new callerID was just added to " . $pbx . "'s blacklist";
	$state = 'Blocked ';
	$f_color = "#FA0404";
	$state_time = $ymdNow;	
} else {
	$msg = 'A number has been added to ' . $pbx . '\'s blacklist callers via feature code *32.';
	$mail->Subject = "A new callerID was just added to " . $pbx . "'s blacklist";
	$state = 'Blocked ';
	$f_color = "#FA0404";
	$state_time = $ymdNow ;
}

$HTMLmessage = '
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8">
    <meta name="description" content="GSM Call Email Notification Alert">
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="x-apple-disable-message-reformatting">
        <link href="https://font.internet.fo/stylesheet.css" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <!--<![endif]-->
    <style>
        html,
        body {
            margin: 0 auto !important;
            padding: 0 !important;
            height: 100% !important;
            width: 100% !important;
        }

        * {
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
        }

        div[style*="margin: 16px 0"] {
            margin:0 !important;
        }

        table,
        td {
            mso-table-lspace: 0pt !important;
            mso-table-rspace: 0pt !important;
        }

        table {
            border-spacing: 0 !important;
            border-collapse: collapse !important;
            table-layout: fixed !important;
            margin: 0 auto !important;
        }
        table table table {
            table-layout: auto;
        }

        img {
            -ms-interpolation-mode:bicubic;
        }

        *[x-apple-data-detectors],	/* iOS */
        .x-gmail-data-detectors, 	/* Gmail */
        .x-gmail-data-detectors *,
        .aBn {
            border-bottom: 0 !important;
            cursor: default !important;
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }

        .a6S {
	        display: none !important;
	        opacity: 0.01 !important;
        }
        img.g-img + div {
	        display:none !important;
	   	}

        .button-link {
            text-decoration: none !important;
        }

        @media only screen and (min-device-width: 375px) and (max-device-width: 413px) { /* iPhone 6 and 6+ */
            .email-container {
                min-width: 375px !important;
            }
        }

        .button-td,
        .button-a {
            transition: all 100ms ease-in;
        }
        .button-td:hover,
        .button-a:hover {
            background: #555555 !important;
            border-color: #555555 !important;
        }

        @media screen and (max-width: 600px) {

			.email-container p {
				font-size: 17px !important;
				line-height: 22px !important;
			}

		}

	</style>
</head>
<body width="100%" bgcolor="#f6f6f6" style="margin: 0;line-height:1.4;padding:0;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;">
	<center style="width: 100%; background: #f6f6f6; text-align: left;">
		<div style="max-width: 600px; padding: 10px 0; margin: auto;" class="email-container">
			<table role="presentation" cellspacing="0" cellpadding="0" border="0" align="center" width="95%" style="max-width: 600px;">
				<tr>
					<td bgcolor="#ffffff" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;-webkit-border-top-right-radius: 25px;-webkit-border-top-left-radius: 25px;-moz-border-top-right-radius: 25px;-moz-border-top-left-radius: 25px;border-top-right-radius: 25px;border-top-left-radius: 25px;-webkit-border-bottom-right-radius: 25px;-webkit-border-bottom-left-radius: 25px;-moz-border-bottom-right-radius: 25px;-moz-border-bottom-left-radius: 25px;border-bottom-right-radius: 25px;border-bottom-left-radius: 25px;">
<!-- email header -->
            <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;-webkit-border-top-right-radius: 25px;-webkit-border-top-left-radius: 25px;-moz-border-top-right-radius: 25px;-moz-border-top-left-radius: 25px;border-top-right-radius: 25px;border-top-left-radius: 25px;">
                <tbody>
                  <tr>
                    <td style="background-color:#424242;-webkit-border-top-right-radius: 25px;-webkit-border-top-left-radius: 25px;-moz-border-top-right-radius: 25px;-moz-border-top-left-radius: 25px;border-top-right-radius: 25px;border-top-left-radius: 25px;">
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; color:#ffffff; text-align:center;">GSM Call Alert & Notification Services</h2>
                    </td>
                  </tr>
                  <tr>
                    <td style="background-color:' .$f_color. ';">
                      <h1 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; padding:0; margin:10px; color:#ffffff; text-align:center;">' .$msg. '</h1>
                    </td>
                  </tr>
                </tbody>
            </table>
<!-- email header END -->
<!-- email Picture -->
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;border-left-style: solid;border-right-style: solid;border-color: #d3d3d3;border-width: 1px;">
              <td style="font-size:16px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h5 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; color:#b0b0b0; text-align:right; padding-right:5%;">Alert Time Stamp ' . $ymdNow . '</h5>

<table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;">
<tr style="border-collapse:collapse;">
<td align="center" style="padding:0;Margin:0;">
<img src="https://gsmcall.com/wp-content/uploads/2020/02/gsmcall-Web-Large-Blue-Font.png" alt style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;" width="414" height="102">
</td></tr></table>
<!-- email Picture END -->
<!-- email Body -->
                    </td>
                  </tr>
                </tbody>
				
                <td style="font-size:9px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Phone Number ' .$state . ':</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $blk_num . '  (' . $clrid . ')</h2>
                    </td>
                  </tr>
                </tbody>

                <td style="font-size:9px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Block (Date/Time):</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $state_time . '</h2>
                    </td>
                  </tr>
                </tbody>

                <td style="font-size:9px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">'.$state.' By:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $blkerr . '</h2>
                    </td>
                  </tr>
                </tbody>' 
				
				. $HTMLmsg .

                '<td style="font-size:9px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">'.$state.' Via:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">Dial Plan *' .$dialed_number.'</h2>
                    </td>
                  </tr>
                </tbody>
				
                <td style="font-size:9px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Description:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $clrid . '</h2>
                    </td>
                  </tr>
                </tbody>

              <td style="font-size:16px;vertical-align:top;">&nbsp;</td>
            </table>
<!-- email Body END -->
<!-- email fotter -->
            <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;-webkit-border-bottom-right-radius: 25px;-webkit-border-bottom-left-radius: 25px;-moz-border-bottom-right-radius: 25px;-moz-border-bottom-left-radius: 25px;border-bottom-right-radius: 25px;border-bottom-left-radius: 25px;">
              <tbody>
                <tr>
                  <td style="background-color:' .$f_color. ';">
                    <h1 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; padding:0; margin:10px; color:#ffffff; text-align:center;">' .$msg. '</h1>
                  </td>
                </tr>
                <tr>
                  <td style="background-color:#424242;-webkit-border-bottom-right-radius: 25px;-webkit-border-bottom-left-radius: 25px;-moz-border-bottom-right-radius: 25px;-moz-border-bottom-left-radius: 25px;border-bottom-right-radius: 25px;border-bottom-left-radius: 25px;">
                    <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; color:#ffffff; text-align:center;">GSM Call Alert & Notification Services</h2>
                  </td>
                </tr>
              </tbody>
            </table>
					</td>
				</tr>
			</table>
		</div>
    </center>
</body>
</html>';

$mail->Body = $HTMLmessage;

try {
    $mail->send();
//    echo "Message has been sent successfully";

} catch (Exception $e) {
    //$err = "Mailer Error: " . $mail->ErrorInfo;
}
?>