<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once "vendor/autoload.php";

// Variables for HTML presentation.
date_default_timezone_set("America/New_York");
$ymdNow = date("m/d/Y") . ' @ ' . date("h:i:sa");

isset($_POST['mode']) ? $mode = $_POST['mode'] : $mode = '';
isset($_POST['timestamp']) ? $timestamp = $_POST['timestamp'] : $timestamp = $ymdNow ;
!empty($_POST['timestamp']) ? $timestamp = $_POST['timestamp'] : $timestamp = $ymdNow ;
isset($_POST['addedby']) ? $addedby = $_POST['addedby'] : $addedby = '';
isset($_POST['addedvia']) ? $addedvia = $_POST['addedvia'] : $addedvia = '';
isset($_POST['number']) ? $number = $_POST['number'] : $number = '';
isset($_POST['oldval']) ? $oldval = $_POST['oldval'] : $oldval = '';
isset($_POST['toMail']) ? $toMail = $_POST['toMail'] : $toMail = '';
isset($_POST['description']) ? $desc = $_POST['description'] : $desc = '';

if (empty($toMail)){
$agi->verbose('----------> Email not set, EXITSING script now');	
	exit;
}

//PHPMailer Object
$mail = new PHPMailer(true); //Argument true in constructor enables exceptions

//From email address and name
$mail->From = "support@gsmcall.com";
$mail->FromName = "BlackList Module Notification";

//To address and name
$mail->addAddress($toMail);
//$mail->addAddress("recepient1@example.com", "Recipient_name"); //Recipient name is optional

//Address to which recipient will reply
$mail->addReplyTo("support@gsmcall.com", "Reply");

//CC and BCC
//$mail->addCC("cc@example.com");
//$mail->addBCC("bcc@example.com");

//Send HTML or Plain Text email
$mail->isHTML(true);

// switch between add and modify
if ($mode == "edit"){
	$msg = 'A blacklisted number has been modified on ' . $_POST['host'] . '\'s PBX';
	$mail->Subject = "A callerID has been just modified that was on " . $_POST['host'] . "'s blacklist";
	$f_color = "#FA0404";
} elseif ($mode == 'delete') {
	$msg = 'A blacklisted number has just been removed from ' . $_POST['host'] . '\'s PBX';
	$mail->Subject = "A callerID has just been unblocked from " . $_POST['host'] . "'s blacklist";
	$f_color = "#83F905";
} else {
	$msg = 'A number has been added to ' . $_POST['host'] . '\'s blacklist callers.';
	$mail->Subject = "A new callerID was just added to " . $_POST['host'] . "'s blacklist";
	$f_color = "#FA0404";
}

if ($mode == 'delete') {

$HTMLmessage = '

<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8">
    <meta name="description" content="GSM Call Email Notification Alert">
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="x-apple-disable-message-reformatting">
    <title>' . $f_host_alias . ' / ' . $f_serv_desc . '</title>

    <!--[if mso]>
        <style>
            * {
                font-family: sans-serif !important;
            }
        </style>
    <![endif]-->

    <!--[if !mso]><!-->
        <link href="https://font.internet.fo/stylesheet.css" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <!--<![endif]-->

    <style>

        html,
        body {
            margin: 0 auto !important;
            padding: 0 !important;
            height: 100% !important;
            width: 100% !important;
        }

        * {
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
        }

        div[style*="margin: 16px 0"] {
            margin:0 !important;
        }

        table,
        td {
            mso-table-lspace: 0pt !important;
            mso-table-rspace: 0pt !important;
        }

        table {
            border-spacing: 0 !important;
            border-collapse: collapse !important;
            table-layout: fixed !important;
            margin: 0 auto !important;
        }
        table table table {
            table-layout: auto;
        }

        img {
            -ms-interpolation-mode:bicubic;
        }

        *[x-apple-data-detectors],	/* iOS */
        .x-gmail-data-detectors, 	/* Gmail */
        .x-gmail-data-detectors *,
        .aBn {
            border-bottom: 0 !important;
            cursor: default !important;
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }

        .a6S {
	        display: none !important;
	        opacity: 0.01 !important;
        }
        img.g-img + div {
	        display:none !important;
	   	}

        .button-link {
            text-decoration: none !important;
        }

        @media only screen and (min-device-width: 375px) and (max-device-width: 413px) { /* iPhone 6 and 6+ */
            .email-container {
                min-width: 375px !important;
            }
        }

    </style>

    <style>

        .button-td,
        .button-a {
            transition: all 100ms ease-in;
        }
        .button-td:hover,
        .button-a:hover {
            background: #555555 !important;
            border-color: #555555 !important;
        }

        @media screen and (max-width: 600px) {

			.email-container p {
				font-size: 17px !important;
				line-height: 22px !important;
			}

		}

	</style>

	<!--[if gte mso 9]>
	<xml>
		<o:OfficeDocumentSettings>
			<o:AllowPNG/>
			<o:PixelsPerInch>96</o:PixelsPerInch>
		</o:OfficeDocumentSettings>
	</xml>
	<![endif]-->

</head>


<body width="100%" bgcolor="#f6f6f6" style="margin: 0;line-height:1.4;padding:0;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;">
	<center style="width: 100%; background: #f6f6f6; text-align: left;">

<!-- appears on the Subject line
		<div style="display:none;font-size:1px;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;mso-hide:all;font-family: sans-serif;">
			[' .$f_notify_type. '] Service: ' .$f_serv_desc. ' on Host: ' .$f_host_alias. ' (' .$f_host_name. ') is ' .$f_serv_state. '. ***************************************************************************************************************************************
		</div>
-->
		<div style="max-width: 600px; padding: 10px 0; margin: auto;" class="email-container">
			<!--[if mso]>
			<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" align="center">
			<tr>
			<td>
			<![endif]-->

			<table role="presentation" cellspacing="0" cellpadding="0" border="0" align="center" width="95%" style="max-width: 600px;">
				<tr>
					<td bgcolor="#ffffff" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;-webkit-border-top-right-radius: 25px;-webkit-border-top-left-radius: 25px;-moz-border-top-right-radius: 25px;-moz-border-top-left-radius: 25px;border-top-right-radius: 25px;border-top-left-radius: 25px;-webkit-border-bottom-right-radius: 25px;-webkit-border-bottom-left-radius: 25px;-moz-border-bottom-right-radius: 25px;-moz-border-bottom-left-radius: 25px;border-bottom-right-radius: 25px;border-bottom-left-radius: 25px;">
            
			<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;-webkit-border-top-right-radius: 25px;-webkit-border-top-left-radius: 25px;-moz-border-top-right-radius: 25px;-moz-border-top-left-radius: 25px;border-top-right-radius: 25px;border-top-left-radius: 25px;">
                <tbody>
                  <tr>
                    <td style="background-color:#424242;-webkit-border-top-right-radius: 25px;-webkit-border-top-left-radius: 25px;-moz-border-top-right-radius: 25px;-moz-border-top-left-radius: 25px;border-top-right-radius: 25px;border-top-left-radius: 25px;">
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; color:#ffffff; text-align:center;">GSM Call Alert & Notification Services</h2>
                    </td>
                  </tr>
                  
				  <tr>
                    <td style="background-color:' .$f_color. ';">
                      <h1 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; padding:0; margin:10px; color:#ffffff; text-align:center;">' . $msg . '</h1>
                    </td>
                  </tr>
                </tbody>
            </table>
			
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;border-left-style: solid;border-right-style: solid;border-color: #d3d3d3;border-width: 1px;">
              
			  <td style="font-size:16px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h5 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; color:#b0b0b0; text-align:right; padding-right:5%;">Alert Time Stamp ' . $ymdNow . '</h5>

<table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;">
<tr style="border-collapse:collapse;">
<td align="center" style="padding:0;Margin:0;">
<img src="https://gsmcall.com/wp-content/uploads/2020/02/gsmcall-Web-Large-Blue-Font.png" alt style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;" width="414" height="102">
</td></tr></table>

					</td>
                  </tr>
                </tbody>
				
<!-- phone number unblocked -->

                <td style="font-size:9px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">

<!-- Phone Number Un-Blocked -->
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Phone Number Un-Blocked:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $number . '</h2>
                    </td>
                  </tr>
                </tbody>

<!-- Timestamp of removed record --> 
				
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Date/Time Number Originally Blocked on:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $timestamp . '</h2>
                    </td>
                  </tr>
                </tbody>
				
<!-- addedby --> 
				
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Number was Blocked By:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $addedby . '</h2>
                    </td>
                  </tr>
                </tbody>

<!-- addedvia --> 
				
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Number was Blocked Via:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $addedvia . '</h2>
                    </td>
                  </tr>
                </tbody>
<!-- Description --> 
				
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Description:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $desc . '</h2>
                    </td>
                  </tr>
                </tbody>
				
<!-- Again Notification type here -->				
				
            <td style="font-size:16px;vertical-align:top;">&nbsp;</td>
            </table>
            <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;-webkit-border-bottom-right-radius: 25px;-webkit-border-bottom-left-radius: 25px;-moz-border-bottom-right-radius: 25px;-moz-border-bottom-left-radius: 25px;border-bottom-right-radius: 25px;border-bottom-left-radius: 25px;">
              <tbody>
                <tr>
                  <td style="background-color:' .$f_color. ';">
                    <h1 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; padding:0; margin:10px; color:#ffffff; text-align:center;">' .$msg. '</h1>
                  </td>
                </tr>

                <tr>
                  <td style="background-color:#424242;-webkit-border-bottom-right-radius: 25px;-webkit-border-bottom-left-radius: 25px;-moz-border-bottom-right-radius: 25px;-moz-border-bottom-left-radius: 25px;border-bottom-right-radius: 25px;border-bottom-left-radius: 25px;">
                    <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; color:#ffffff; text-align:center;">GSM Call Alert & Notification Services</h2>
                  </td>
                </tr>
              </tbody>
            </table>
					</td>
				</tr>
			</table>

			<!--[if mso]>
			</td>
			</tr>
			</table>
			<![endif]-->
		</div>

    </center>
</body>
</html>';

} else {

// forming the HTML email document for adding and editing
$HTMLmessage = '

<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8">
    <meta name="description" content="GSM Call Email Notification Alert">
    <meta name="viewport" content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="x-apple-disable-message-reformatting">
    <title>' . $f_host_alias . ' / ' . $f_serv_desc . '</title>

    <!--[if mso]>
        <style>
            * {
                font-family: sans-serif !important;
            }
        </style>
    <![endif]-->

    <!--[if !mso]><!-->
        <link href="https://font.internet.fo/stylesheet.css" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <!--<![endif]-->

    <style>

        html,
        body {
            margin: 0 auto !important;
            padding: 0 !important;
            height: 100% !important;
            width: 100% !important;
        }

        * {
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
        }

        div[style*="margin: 16px 0"] {
            margin:0 !important;
        }

        table,
        td {
            mso-table-lspace: 0pt !important;
            mso-table-rspace: 0pt !important;
        }

        table {
            border-spacing: 0 !important;
            border-collapse: collapse !important;
            table-layout: fixed !important;
            margin: 0 auto !important;
        }
        table table table {
            table-layout: auto;
        }

        img {
            -ms-interpolation-mode:bicubic;
        }

        *[x-apple-data-detectors],	/* iOS */
        .x-gmail-data-detectors, 	/* Gmail */
        .x-gmail-data-detectors *,
        .aBn {
            border-bottom: 0 !important;
            cursor: default !important;
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }

        .a6S {
	        display: none !important;
	        opacity: 0.01 !important;
        }
        img.g-img + div {
	        display:none !important;
	   	}

        .button-link {
            text-decoration: none !important;
        }

        @media only screen and (min-device-width: 375px) and (max-device-width: 413px) { /* iPhone 6 and 6+ */
            .email-container {
                min-width: 375px !important;
            }
        }

    </style>

    <style>

        .button-td,
        .button-a {
            transition: all 100ms ease-in;
        }
        .button-td:hover,
        .button-a:hover {
            background: #555555 !important;
            border-color: #555555 !important;
        }

        @media screen and (max-width: 600px) {

			.email-container p {
				font-size: 17px !important;
				line-height: 22px !important;
			}

		}

	</style>

	<!--[if gte mso 9]>
	<xml>
		<o:OfficeDocumentSettings>
			<o:AllowPNG/>
			<o:PixelsPerInch>96</o:PixelsPerInch>
		</o:OfficeDocumentSettings>
	</xml>
	<![endif]-->

</head>


<body width="100%" bgcolor="#f6f6f6" style="margin: 0;line-height:1.4;padding:0;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;">
	<center style="width: 100%; background: #f6f6f6; text-align: left;">

<!-- appears on the Subject line
		<div style="display:none;font-size:1px;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;mso-hide:all;font-family: sans-serif;">
			[' .$f_notify_type. '] Service: ' .$f_serv_desc. ' on Host: ' .$f_host_alias. ' (' .$f_host_name. ') is ' .$f_serv_state. '. ***************************************************************************************************************************************
		</div>
-->
		<div style="max-width: 600px; padding: 10px 0; margin: auto;" class="email-container">
			<!--[if mso]>
			<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" align="center">
			<tr>
			<td>
			<![endif]-->

			<table role="presentation" cellspacing="0" cellpadding="0" border="0" align="center" width="95%" style="max-width: 600px;">
				<tr>
					<td bgcolor="#ffffff" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;-webkit-border-top-right-radius: 25px;-webkit-border-top-left-radius: 25px;-moz-border-top-right-radius: 25px;-moz-border-top-left-radius: 25px;border-top-right-radius: 25px;border-top-left-radius: 25px;-webkit-border-bottom-right-radius: 25px;-webkit-border-bottom-left-radius: 25px;-moz-border-bottom-right-radius: 25px;-moz-border-bottom-left-radius: 25px;border-bottom-right-radius: 25px;border-bottom-left-radius: 25px;">
            
			<table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;-webkit-border-top-right-radius: 25px;-webkit-border-top-left-radius: 25px;-moz-border-top-right-radius: 25px;-moz-border-top-left-radius: 25px;border-top-right-radius: 25px;border-top-left-radius: 25px;">
                <tbody>
                  <tr>
                    <td style="background-color:#424242;-webkit-border-top-right-radius: 25px;-webkit-border-top-left-radius: 25px;-moz-border-top-right-radius: 25px;-moz-border-top-left-radius: 25px;border-top-right-radius: 25px;border-top-left-radius: 25px;">
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; color:#ffffff; text-align:center;">GSM Call Alert & Notification Services</h2>
                    </td>
                  </tr>
                  
				  <tr>
                    <td style="background-color:' .$f_color. ';">
                      <h1 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; padding:0; margin:10px; color:#ffffff; text-align:center;">' . $msg . '</h1>
                    </td>
                  </tr>
                </tbody>
            </table>
			
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;border-left-style: solid;border-right-style: solid;border-color: #d3d3d3;border-width: 1px;">
              
			  <td style="font-size:16px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h5 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; color:#b0b0b0; text-align:right; padding-right:5%;">Alert Time Stamp ' . $ymdNow . '</h5>

<table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;">
<tr style="border-collapse:collapse;">
<td align="center" style="padding:0;Margin:0;">
<img src="https://gsmcall.com/wp-content/uploads/2020/02/gsmcall-Web-Large-Blue-Font.png" alt style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;" width="414" height="102">
</td></tr></table>

					</td>
                  </tr>
                </tbody>';
		
if (empty($oldval)){
// newly added number	
$HTMLmessage .= '<!-- Variable presentation goes from here -->

                <td style="font-size:9px;vertical-align:top;">&nbsp;</td>
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
<!-- Phone Number Blocked -->
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Phone Number Blocked:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $number . '</h2>
                    </td>
                  </tr>
                </tbody>';
}

if (($mode == "edit") && (intval($oldval) <> intval($number))) {
	
$HTMLmessage .= '<td style="font-size:9px;vertical-align:top;">&nbsp;</td>
				<tbody>
					<tr>
						<td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
<!-- old Phone Number Blocked -->
						<h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">CallerID before modification:</h4>
						<h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $oldval . '</h2>
						</td>
					</tr>
                </tbody>';
} 

if (!empty($oldval)) {
	
$HTMLmessage .= '<td style="font-size:9px;vertical-align:top;">&nbsp;</td>
				<tbody>
					<tr>
						<td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
<!-- newly modified Phone Number Blocked -->
						<h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">CallerID currently blocked after modification:</h4>
						<h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $number . '</h2>
						</td>
					</tr>
                </tbody>';
}		
		
$HTMLmessage .= '<td style="font-size:9px;vertical-align:top;">&nbsp;</td>
<!-- Date Time -->
                <td style="font-size:9px;vertical-align:top;">&nbsp;</td>

<!-- Timestamp of removed record --> 
				
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Date/Time Number Originally Blocked on:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $timestamp . '</h2>
                    </td>
                  </tr>
                </tbody>
				
<!-- Blocked By -->
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Blocked By:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $addedby . '</h2>
                    </td>
                  </tr>
                </tbody>
				
<!-- Blocked Via --> 
				
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Blocked Via:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $addedvia . '</h2>
                    </td>
                  </tr>
                </tbody>
				
<!-- Description --> 
				
                <tbody>
                  <tr>
                    <td width="98%" style="vertical-align:middle;font-size:14px;width:98%;margin:0 10px 0 10px;">
                      <h4 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:15px; color:#b0b0b0; padding-left:3%;text-decoration:underline;">Description:</h4>
                      <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; font-size:20px; padding-left:5%;">' . $desc . '</h2>
                    </td>
                  </tr>
                </tbody>
				
<!-- Again Notification type here -->				
				
              <td style="font-size:16px;vertical-align:top;">&nbsp;</td>
            </table>
            <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:separate;mso-table-lspace:0pt;mso-table-rspace:0pt;width:100%;-webkit-border-bottom-right-radius: 25px;-webkit-border-bottom-left-radius: 25px;-moz-border-bottom-right-radius: 25px;-moz-border-bottom-left-radius: 25px;border-bottom-right-radius: 25px;border-bottom-left-radius: 25px;">
              <tbody>
                <tr>
                  <td style="background-color:' .$f_color. ';">
                    <h1 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; padding:0; margin:10px; color:#ffffff; text-align:center;">' .$msg. '</h1>
                  </td>
                </tr>

                <tr>
                  <td style="background-color:#424242;-webkit-border-bottom-right-radius: 25px;-webkit-border-bottom-left-radius: 25px;-moz-border-bottom-right-radius: 25px;-moz-border-bottom-left-radius: 25px;border-bottom-right-radius: 25px;border-bottom-left-radius: 25px;">
                    <h2 style="font-family: CoconPro-BoldCond, Open Sans, Verdana, sans-serif; margin:0; color:#ffffff; text-align:center;">GSM Call Alert & Notification Services</h2>
                  </td>
                </tr>
              </tbody>
            </table>
					</td>
				</tr>
			</table>

			<!--[if mso]>
			</td>
			</tr>
			</table>
			<![endif]-->
		</div>

    </center>
</body>
</html>';
}

//$mail->Body = "<i>Mail body in HTML</i>"; 
//$mail->AltBody = "This is the plain text version of the email content";
$mail->Body = $HTMLmessage;

try {
    $mail->send();
//    echo "Message has been sent successfully";

} catch (Exception $e) {
    //$err = "Mailer Error: " . $mail->ErrorInfo;
}